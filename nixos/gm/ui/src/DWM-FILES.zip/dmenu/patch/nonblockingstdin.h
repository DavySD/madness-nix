static void readevent();
